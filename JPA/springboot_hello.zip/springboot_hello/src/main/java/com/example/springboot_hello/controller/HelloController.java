package com.example.springboot_hello.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController //不可以用Controller,因为此处为了不让字符串当成路径跳转，需要声明返回json，而RestControlloer包含了 Controller和ResponseBody注解
@RequestMapping("/v1")
public class HelloController {

    @RequestMapping("/say")
    public String sayHello(){
        return "hello world springboot";
    }
}
